package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    //declare variables
    RadioGroup radioGroupPetrol;
    String fuelType = "";

    Button btnCalc;
    Button btnReset;
    TextView tvResult;
    EditText numPrice;
    EditText numAmountFuel;
    TextView tvEligibleStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        numAmountFuel = findViewById(R.id.numAmountFuel);
        numPrice = findViewById(R.id.numPrice);
        radioGroupPetrol = findViewById(R.id.radioGroupPetrol);
        btnCalc = findViewById(R.id.btnCalc);
        btnReset = findViewById(R.id.btnReset);
        tvResult = findViewById(R.id.tvResult);
        tvEligibleStatus = findViewById(R.id.tvEligibleStatus);
        tvEligibleStatus.setVisibility(View.GONE);

        // =========================
        // PETROL TYPE SELECT
        // =========================
        radioGroupPetrol.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (checkedId == -1) {
                    tvEligibleStatus.setVisibility(View.GONE);
                    return;
                }

                RadioButton selectedRadio = findViewById(checkedId);
                fuelType = selectedRadio.getText().toString();

                if (fuelType.equals("RON95")) {
                    tvEligibleStatus.setVisibility(View.VISIBLE);
                } else {
                    tvEligibleStatus.setVisibility(View.GONE);
                }
            }
        });


        // =========================
        // CALCULATE BUTTON
        // =========================
        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int selectedId = radioGroupPetrol.getCheckedRadioButtonId();

                // CHECK FUEL TYPE
                if (selectedId == -1) {
                    Toast.makeText(MainActivity.this,
                            "Please select the fuel type",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                RadioButton selectedRadioButton = findViewById(selectedId);
                String fuelType = selectedRadioButton.getText().toString();

                // CHECK EMPTY INPUT
                if (numPrice.getText().toString().trim().isEmpty()) {

                    Toast.makeText(MainActivity.this,
                            "Please enter the price of petrol.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                if (numAmountFuel.getText().toString().trim().isEmpty()) {
                    Toast.makeText(MainActivity.this,
                            "Please enter amount of fuel required.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // PARSE ONCE (IMPORTANT FIX)
                double price = Double.parseDouble(numPrice.getText().toString());
                double usage = Double.parseDouble(numAmountFuel.getText().toString());

                double totalCost = usage * price;
                double totalCost2 = usage * price;
                double subsidyRate = 1.99;
                double budiRebate = 0;
                double saving = 0;

                boolean isEligible = fuelType.equals("RON95");

                if (isEligible) {
                    budiRebate = usage * subsidyRate;
                    saving = totalCost - budiRebate;
                } else {
                    saving = totalCost;
                }

                // RESULT DISPLAY BASED ON FUEL TYPE
                if (fuelType.equals("RON95")) {

                    tvResult.setText(
                            "Fuel Type: RON95" +
                                    "\nTotal Petrol Cost: RM " + String.format("%.2f", totalCost) +
                                    "\nBUDI Rebate: RM " + String.format("%.2f", budiRebate) +
                                    "\nTotal Saving: RM " + String.format("%.2f", saving)
                    );

                } else if (fuelType.equals("RON97")) {

                    tvResult.setText(
                            "Fuel Type: RON97\n Total Petrol Cost: RM "
                                    + String.format("%.2f", totalCost2)
                    );

                } else if (fuelType.equals("Diesel")) {

                    tvResult.setText(
                            "Fuel Type: Diesel\n Total Petrol Cost: RM " +
                                    String.format("%.2f", totalCost2)
                    );
                }

                tvResult.setVisibility(View.VISIBLE);


            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // reset radio button
                radioGroupPetrol.clearCheck();

                // reset input fields
                numPrice.setText("");
                numAmountFuel.setText("");

                // reset text result
                tvResult.setText("Result will appear here...");
                tvResult.setVisibility(View.GONE);

                // hide eligible status
                tvEligibleStatus.setVisibility(View.GONE);

                // reset variable
                fuelType = "";

                Toast.makeText(MainActivity.this,
                        "Form Reset Successfully",
                        Toast.LENGTH_SHORT).show();
            }
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(WindowInsetsCompat.Type.systemBars());

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_about) {

            Intent intent =
                    new Intent(MainActivity.this,
                            AboutActivity.class);

            startActivity(intent);
            return true;

        } else if (id == R.id.action_home) {

            Intent intent = new Intent(MainActivity.this, MainActivity.class);
            startActivity(intent);
            finish();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}